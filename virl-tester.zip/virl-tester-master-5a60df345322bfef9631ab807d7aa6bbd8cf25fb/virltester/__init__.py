# -*- coding: utf-8 -*-

from .virltester import main

